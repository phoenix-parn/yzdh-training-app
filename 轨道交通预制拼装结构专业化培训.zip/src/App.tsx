import { useState } from "react";
import { HomePage } from "./components/HomePage";
import { CoursesPage } from "./components/CoursesPage";
import { CourseDetailPage } from "./components/CourseDetailPage";
import { ResourcesPage } from "./components/ResourcesPage";
import { ProfilePage } from "./components/ProfilePage";
import { BottomNav } from "./components/BottomNav";

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const renderPage = () => {
    // 检查是否是课程详情页（格式：course-detail-MF01）
    if (currentPage.startsWith("course-detail-")) {
      const courseId = currentPage.replace("course-detail-", "");
      return <CourseDetailPage onNavigate={handleNavigate} courseId={courseId} />;
    }

    switch (currentPage) {
      case "home":
        return <HomePage onNavigate={handleNavigate} />;
      case "courses":
        return <CoursesPage onNavigate={handleNavigate} />;
      case "course-detail":
        return <CourseDetailPage onNavigate={handleNavigate} />;
      case "resources":
        return <ResourcesPage onNavigate={handleNavigate} />;
      case "profile":
        return <ProfilePage onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  const showBottomNav = ["home", "courses", "resources", "profile"].includes(
    currentPage
  );

  return (
    <div className="relative min-h-screen bg-background">
      {renderPage()}
      {showBottomNav && (
        <BottomNav activePage={currentPage} onNavigate={handleNavigate} />
      )}
    </div>
  );
}