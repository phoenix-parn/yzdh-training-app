import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Heart,
  Download,
  Settings,
  Clock,
} from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { courseData } from "../data/courseData";

interface ProfilePageProps {
  onNavigate: (page: string) => void;
}

export function ProfilePage({ onNavigate }: ProfilePageProps) {
  const menuItems = [
    {
      id: 1,
      icon: BookOpen,
      title: "我的学习",
      subtitle: "已学习5门课程 · 累计12小时30分",
      color: "text-primary",
      bgColor: "bg-[#E6F0FF]",
    },
    {
      id: 2,
      icon: Heart,
      title: "我的收藏",
      subtitle: "8个收藏内容",
      color: "text-[#FF6B6B]",
      bgColor: "bg-[#FFE6E6]",
    },
    {
      id: 3,
      icon: Download,
      title: "下载管理",
      subtitle: "3个已下载文件",
      color: "text-[#00C853]",
      bgColor: "bg-[#E6F9F0]",
    },
    {
      id: 4,
      icon: Settings,
      title: "设置",
      subtitle: "账号与系统设置",
      color: "text-[#666666]",
      bgColor: "bg-[#F5F5F5]",
    },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-[#F5F5F5]">
      {/* 顶部导航栏 */}
      <div className="bg-white px-4 py-3 flex items-center gap-3 border-b border-border">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9"
          onClick={() => onNavigate("home")}
        >
          <ChevronLeft className="h-5 w-5 text-[#333333]" />
        </Button>
        <h1 className="text-[#333333]">个人中心</h1>
      </div>

      {/* 用户信息栏 */}
      <div className="bg-white p-4 border-b border-border">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarImage src="" />
            <AvatarFallback className="bg-primary text-primary-foreground text-[24px]">
              张
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h2 className="text-[#333333] mb-1">张工程师</h2>
            <p className="text-[14px] text-[#666666]">施工项目经理</p>
          </div>
          <Button variant="ghost" size="icon" className="h-9 w-9 flex-shrink-0">
            <ChevronRight className="h-5 w-5 text-[#666666]" />
          </Button>
        </div>
      </div>

      {/* 学习统计卡片 */}
      <div className="p-4">
        <Card className="p-4">
          <div className="grid grid-cols-3 divide-x divide-border">
            <div className="text-center">
              <div className="text-[24px] text-primary mb-1">2</div>
              <div className="text-[12px] text-[#666666]">在学课程</div>
            </div>
            <div className="text-center">
              <div className="text-[24px] text-primary mb-1">0</div>
              <div className="text-[12px] text-[#666666]">已完成</div>
            </div>
            <div className="text-center">
              <div className="text-[24px] text-primary mb-1">5.2h</div>
              <div className="text-[12px] text-[#666666]">总学习时长</div>
            </div>
          </div>
        </Card>
      </div>

      {/* 功能列表 */}
      <div className="px-4 pb-4 space-y-3">
        {menuItems.map((item) => (
          <Card
            key={item.id}
            className="p-4 cursor-pointer hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-4">
              <div
                className={`flex-shrink-0 w-12 h-12 rounded-lg ${item.bgColor} flex items-center justify-center`}
              >
                <item.icon className={`h-6 w-6 ${item.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-[#333333] mb-1">{item.title}</h3>
                <p className="text-[12px] text-[#666666]">{item.subtitle}</p>
              </div>
              <ChevronRight className="h-5 w-5 text-[#CCCCCC] flex-shrink-0" />
            </div>
          </Card>
        ))}
      </div>

      {/* 最近学习记录 */}
      <div className="px-4 pb-20">
        <h3 className="text-[#333333] mb-3">最近学习</h3>
        <Card className="divide-y divide-border">
          {courseData.工法分类列表.slice(0, 2).map((course, index) => (
            <div
              key={course.工法ID}
              className="p-3 cursor-pointer hover:bg-[#F5F5F5] transition-colors"
              onClick={() => onNavigate(`course-detail-${course.工法ID}`)}
            >
              <div className="flex items-start gap-3">
                <Clock className="h-4 w-4 text-[#666666] mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[14px] text-[#333333] mb-1">
                    {course.工法名称}
                  </p>
                  <p className="text-[12px] text-[#666666]">
                    {course.模块列表[0].模块名称}
                  </p>
                </div>
                <span className="text-[12px] text-[#999999] flex-shrink-0">
                  {index === 0 ? "2小时前" : "1天前"}
                </span>
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}