
  # 轨道交通预制拼装结构专业化培训

  This is a code bundle for 轨道交通预制拼装结构专业化培训. The original project is available at https://www.figma.com/design/u0rinJVBBreRaysVgLjwrS/%E8%BD%A8%E9%81%93%E4%BA%A4%E9%80%9A%E9%A2%84%E5%88%B6%E6%8B%BC%E8%A3%85%E7%BB%93%E6%9E%84%E4%B8%93%E4%B8%9A%E5%8C%96%E5%9F%B9%E8%AE%AD.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  